import express from 'express';
import net from 'net';
import { fileURLToPath } from 'url';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const newExpressServer = (port) => {
  const server = express();

  server.use(express.static(path.join(__dirname, 'dist')));
  server.use(express.static('./data'));
  server.use(express.static('./tour-example-data'));

  server.get('*', (_, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });

  server.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
  });
};

const findAvailablePort = (port) => {
  return new Promise((resolve) => {
    const server = net.createServer();

    server.once('error', async ({ code }) => {
      if (code !== 'EADDRINUSE') return resolve(port);

      resolve(await findAvailablePort(port + 1));
    });

    server.once('listening', () => {
      server.close();

      resolve(port);
    });

    server.listen(port);
  });
};

export const createServer = async (originPort) => {
  const port = await findAvailablePort(originPort);

  newExpressServer(port);

  return port;
};
