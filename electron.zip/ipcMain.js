import {
  ipcMain,
  globalShortcut,
  clipboard,
  nativeImage,
  BrowserWindow,
  screen,
  Menu,
} from 'electron';
import Store from 'electron-store';

class IPC {
  static _instance;

  constructor(mainWindow) {
    this.store = new Store();
    this.mainWindow = mainWindow;
    this.transparentWindow = null;
    this.selectAreaWithBoxWindow = null;
    this.selectAreaByDragWindow = null;
    this.screenShootBounds = {
      id: Date.now(),
      x: 0,
      y: 0,
      width: 800,
      height: 500,
    };
    this.allBounds = [this.screenShootBounds];
    this.isOpeningSelectArea = false;
    this.fullScreenInfo = { width: 0, height: 0 };
    this.defaultGlobalShortcut = {};

    this.initialize();
  }

  initialize() {
    this.defaultGlobalShortcut = this.store.get('globalShortcut', {
      capture: { title: 'Capture', text: 'Ctrl+1' },
      dragDrop: { title: 'Quick Select', text: 'Ctrl+2' },
      selectArea: { title: 'Magic Select', text: 'Ctrl+3' },
    });

    this.setupGlobalShortcut();
    this.setupEvent();
    this.setupFullScreenInfo();
  }

  setupFullScreenInfo() {
    this.fullScreenInfo = screen.getAllDisplays().reduce(
      (acc, { bounds }) => ({
        x: Math.min(acc.x, bounds.x),
        y: Math.min(acc.y, bounds.y),
        width: Math.max(acc.width, bounds.x + bounds.width - acc.x),
        height: Math.max(acc.height, bounds.y + bounds.height - acc.y),
      }),
      { x: Infinity, y: Infinity, width: 0, height: 0 },
    );
  }

  setupEvent() {
    ipcMain.handle('show-context-menu', (e, base64) => this.showContextMenu(base64));
    ipcMain.handle('copy-to-clipboard', (e, base64) => this.copyToClipboard(base64));
    ipcMain.handle('setup-global-shortcut', (e, shortcut) => this.setupGlobalShortcut(shortcut));
    ipcMain.handle('get-global-shortcut', () => this.store.get('globalShortcut'));
    ipcMain.on('captured', (e, base64) => this.onCaptured(base64));
  }

  setupGlobalShortcut(shortcut = this.defaultGlobalShortcut) {
    globalShortcut.unregisterAll();

    if (!shortcut) return;

    this.store.set('globalShortcut', shortcut);

    globalShortcut.register(shortcut.capture.text, () => this.captureScreen());
    globalShortcut.register(shortcut.dragDrop.text, () => this.prepareSelectArea('dragDrop'));
    globalShortcut.register(shortcut.selectArea.text, () => this.prepareSelectArea('selectArea'));

    this.allBounds.forEach((bound, index) => {
      globalShortcut.unregister(`Ctrl+Shift+${index + 1}`);
      globalShortcut.register(`Ctrl+Shift+${index + 1}`, () => this.captureScreen(bound));
    });
  }

  copyToClipboard(base64) {
    const image = nativeImage.createFromDataURL(base64);
    clipboard.writeImage(image);
  }

  async showContextMenu(base64) {
    const menu = Menu.buildFromTemplate([
      {
        label: 'Copy',
        click: () => {
          this.copyToClipboard(base64);
        },
      },
    ]);

    menu.popup(this.mainWindow);
  }

  onCaptured(base64) {
    console.log('captured: ');
  }

  captureScreen(bounds = this.screenShootBounds, captureOption) {
    const { width, height } = bounds;

    if (width > 2 || height > 2) {
      this.mainWindow.webContents.send('capture-screen', bounds, captureOption);
    }
  }

  prepareSelectArea(type) {
    const { width, height } = this.fullScreenInfo;

    this.captureScreen({ x: 0, y: 0, width, height }, { isTemp: true });

    ipcMain.once('captured', (_, fullScreenImage) =>
      this.createTransparentWindow(type, fullScreenImage),
    );
  }

  createTransparentWindow(type, fullScreenImage) {
    const closeWindow = () => this.transparentWindow?.close();

    if (this.transparentWindow?.type === type) {
      return closeWindow();
    }

    closeWindow();

    this.transparentWindow = new BrowserWindow({
      transparent: true,
      frame: false,
      show: false,
      alwaysOnTop: true,
      fullscreen: false,
      skipTaskbar: true,
      resizable: false,
      focusable: true,
      hasShadow: false,
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false,
      },
    });

    this.transparentWindow.type = type;
    this.transparentWindow.setBounds(this.fullScreenInfo);
    this.transparentWindow.show();

    const fileByType = {
      dragDrop: 'select-by-drag-window.html',
      selectArea: 'select-with-box-window.html',
    };

    this.transparentWindow.loadFile(fileByType[type]);

    this.transparentWindow.webContents.once('did-finish-load', () => {
      this.transparentWindow.webContents.send(
        'set-background-image',
        fullScreenImage,
        this.allBounds,
      );
    });

    ipcMain.once('selected-area', (_, ssBounds, allBounds) => {
      if (ssBounds.width <= 2 && ssBounds.height <= 2) return closeWindow();

      this.screenShootBounds = ssBounds;
      this.allBounds = allBounds || [...this.allBounds, ssBounds];

      this.setupGlobalShortcut();

      this.captureScreen(ssBounds, { imgBase64: fullScreenImage });

      ipcMain.once('captured', closeWindow);
    });

    ipcMain.on('save-bounds', (_, allBounds) => {
      this.allBounds = allBounds;

      this.setupGlobalShortcut();
    });

    this.transparentWindow.once('close', () => {
      this.transparentWindow = null;
      ipcMain.removeAllListeners('selected-area');
      ipcMain.removeAllListeners('save-bounds');
    });
  }
}

export function setupIPC(mainWindow, serverPort) {
  const LOCALHOST = `http://localhost:${serverPort}`;

  new IPC(mainWindow);
}
