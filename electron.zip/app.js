import { app, BrowserWindow, Tray, Menu } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import { setupIPC } from './ipcMain.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export function createMainWindow(serverPort) {
  const mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    x: 1920,
    y: 0,
    show: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'public', 'app-icon-sm-3.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: false,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  mainWindow.loadURL(`http://localhost:${serverPort}`);
  mainWindow.on('close', (event) => {
    event.preventDefault();
    mainWindow.hide();
  });

  setupIPC(mainWindow, serverPort);

  return mainWindow;
}

export function createTray(mainWindow) {
  const appTray = new Tray(path.join(__dirname, 'public', 'app-icon-sm-3.png'));
  appTray.setToolTip('Capture App');

  const showMainWindow = () => {
    mainWindow.maximize();
    mainWindow.focus();
  };

  const createMenu = () => {
    const isVisible = mainWindow.isVisible();

    appTray.setContextMenu(
      Menu.buildFromTemplate([
        {
          label: 'Hiển thị ứng dụng',
          click: showMainWindow,
          visible: !isVisible,
        },
        {
          label: 'Ẩn ứng dụng',
          click: () => mainWindow.hide(),
          visible: isVisible,
        },
        {
          label: 'Thoát',
          click: () => {
            mainWindow.destroy();
            app.quit();
          },
        },
      ]),
    );
  };

  createMenu();

  appTray.on('click', () => (mainWindow.isVisible() ? mainWindow.hide() : showMainWindow()));

  mainWindow.on('show', createMenu);
  mainWindow.on('hide', createMenu);
}
