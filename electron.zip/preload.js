const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  onCaptureScreen: (cb) => ipcRenderer.on('capture-screen', cb),
  captured: (path) => ipcRenderer.send('captured', path),
  copyToClipboard: (base64) => ipcRenderer.invoke('copy-to-clipboard', base64),
  showContextMenu: (base64) => ipcRenderer.invoke('show-context-menu', base64),
  getGlobalShortcut: () => ipcRenderer.invoke('get-global-shortcut'),
  setupGlobalShortcut: (shortcut) => ipcRenderer.invoke('setup-global-shortcut', shortcut),
});
