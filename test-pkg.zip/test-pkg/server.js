const express = require("express");
const path = require("path");

const app = express();
const port = 3000; // Bạn có thể thay đổi port nếu cần

// Cấu hình để trả về file index.html trong thư mục dist/
app.use(express.static(path.join(__dirname, "dist")));

// Cấu hình route mặc định để trả về index.html khi truy cập vào '/'
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

// Lắng nghe trên cổng đã chọn
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
