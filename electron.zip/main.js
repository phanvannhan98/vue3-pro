import { app } from 'electron';
import { createServer } from './server.js';
import { createMainWindow, createTray } from './app.js';

const PORT = 7777;

app.whenReady().then(() => createServer(PORT).then((port) => createTray(createMainWindow(port))));
